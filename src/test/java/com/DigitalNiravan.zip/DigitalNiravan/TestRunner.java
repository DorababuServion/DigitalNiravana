package com.DigitalNiravan;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TestRunner extends StepDefinitionClass {
	
	public Login l = new Login();
	@BeforeClass
	private void OpenBrowser() {
		// TODO Auto-generated method stub
		getDriver();
		maxwin();
	}
	
	@Test
	private void tc1() throws InterruptedException {
		// TODO Auto-generated method stub
		geturl();
		staticwait();
	}
	@Test
	private void tc2() {
		// TODO Auto-generated method stub
		javaexcutor(l.getUsername());
		javaexcutor(l.getPassword());
	}

	@Test
	private void tc3() {
		// TODO Auto-generated method stub
		javaexcutorclick(l.getSignin());
	}	
}
